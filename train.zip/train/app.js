
import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  name = 'angular';
}
var app = angular.module('trainReservationApp', []);

app.controller('SeatReservationController', function ($scope) {
  // Initialize seats
  $scope.seats = [];
  let totalSeats = 80;
  let rows = Math.floor(totalSeats / 7);

  // Create rows (7 seats per row)
  for (let i = 0; i < rows; i++) {
    let row = [];
    for (let j = 1; j <= 7; j++) {
      row.push({ seatNo: i * 7 + j, reserved: false });
    }
    $scope.seats.push(row);
  }

  // Last row with 3 seats
  let lastRow = [];
  for (let i = 1; i <= 3; i++) {
    lastRow.push({ seatNo: 77 + i, reserved: false });
  }
  $scope.seats.push(lastRow);

  // Function to reserve seats
  $scope.reserveSeats = function (seatCount) {
    if (seatCount > 7) {
      alert('You can reserve a maximum of 7 seats.');
      return;
    }

    let availableSeats = [];

    // Check each row for available seats
    for (let i = 0; i < $scope.seats.length; i++) {
      let row = $scope.seats[i];
      let availableInRow = row.filter((seat) => !seat.reserved);

      if (availableInRow.length >= seatCount) {
        // Reserve seats in this row
        for (let j = 0; j < seatCount; j++) {
          availableInRow[j].reserved = true;
        }
        $scope.bookedSeats = availableInRow
          .slice(0, seatCount)
          .map((seat) => seat.seatNo);
        return;
      } else {
        // Push available seats from this row for combining later
        availableSeats = availableSeats.concat(availableInRow);
      }
    }

    // If we reach here, it means no single row has enough seats
    if (availableSeats.length >= seatCount) {
      // Book nearby seats
      for (let i = 0; i < seatCount; i++) {
        availableSeats[i].reserved = true;
      }
      $scope.bookedSeats = availableSeats
        .slice(0, seatCount)
        .map((seat) => seat.seatNo);
    } else {
      alert('Not enough seats available.');
    }
  };
});
